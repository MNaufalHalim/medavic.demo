import React from 'react';
import PageTemplate from '../../components/PageTemplate';

const RiwayatRM = () => {
  return (
    <PageTemplate title="Riwayat Rekam Medis">
      {/* Riwayat RM content */}
    </PageTemplate>
  );
};

export default RiwayatRM;