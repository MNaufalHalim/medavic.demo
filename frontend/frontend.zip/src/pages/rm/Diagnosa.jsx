import React from 'react';
import PageTemplate from '../../components/PageTemplate';

const Diagnosa = () => {
  return (
    <PageTemplate title="Diagnosa">
      {/* Diagnosa content */}
    </PageTemplate>
  );
};

export default Diagnosa;