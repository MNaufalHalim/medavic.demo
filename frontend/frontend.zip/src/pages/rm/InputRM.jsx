import React, { useState, useEffect, useCallback } from 'react';
import PageTemplate from '../../components/PageTemplate';
import { format } from 'date-fns';
import axios from 'axios';
import Select from 'react-select';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

// MedicalRecordModal Component (unchanged)
const MedicalRecordModal = ({ type, title, show, onClose, onSave, selectedItems, recentItems, medicationDetails, onSearch, onSelectItem, onRemoveItem, loading }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [options, setOptions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [commonPresets, setCommonPresets] = useState({});
  const [tempMedication, setTempMedication] = useState(null);
  const [tempPreset, setTempPreset] = useState(null);

  const fetchPresets = useCallback(async (medicationId) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No token found in localStorage');
        return [];
      }
      const response = await axios.get(`http://localhost:5000/api/medical/medication-presets/${medicationId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.data.success) {
        return response.data.data;
      }
      return [];
    } catch (error) {
      console.error('Error fetching presets:', error);
      return [];
    }
  }, []);

  const handleSearch = useCallback(async (term) => {
    if (term.length < 2) {
      setOptions([]);
      return;
    }
    setIsLoading(true);
    try {
      const results = await onSearch(type, term);
      setOptions(results || []);
    } catch (error) {
      setOptions([]);
    } finally {
      setIsLoading(false);
    }
  }, [type, onSearch]);

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      handleSearch(searchTerm);
    }, 300);
    return () => clearTimeout(delayDebounce);
  }, [searchTerm, handleSearch]);

  useEffect(() => {
    if (!show) {
      setSearchTerm('');
      setOptions([]);
      setIsLoading(false);
      setTempMedication(null);
      setTempPreset(null);
    }
  }, [show, type]);

  const handleSelectMedication = async (selectedOption) => {
    if (selectedOption && type === 'medication') {
      setTempMedication(selectedOption);
      const presets = await fetchPresets(selectedOption.id);
      setCommonPresets((prev) => ({
        ...prev,
        [selectedOption.value]: presets,
      }));
      const defaultPreset = presets.find((p) => p.is_default) || presets[0];
      setTempPreset(defaultPreset || null);
    } else if (selectedOption) {
      onSelectItem(type, selectedOption);
    }
  };

  const handleConfirmPreset = () => {
    if (tempMedication && type === 'medication') {
      const medicationName = tempMedication.value;
      onSelectItem(type, tempMedication);
      if (tempPreset) {
        // No need to update local state; rely on parent state
      }
      setTempMedication(null);
      setTempPreset(null);
    }
  };

  const formatSelectedMedication = (item) => {
    if (type === 'medication' && medicationDetails[item]) {
      const { dosage, frequency, duration } = medicationDetails[item];
      return `${item} ${dosage} - ${frequency} - ${duration}`;
    }
    return item;
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-[rgba(0,0,0,0.5)] flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-96">
        <h2 className="text-xl font-bold mb-4">{title}</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Search...</label>
            <Select
              isClearable
              isSearchable
              placeholder={`Cari ${title} (min. 2 huruf)...`}
              options={options}
              inputValue={searchTerm}
              onInputChange={(value, { action }) => {
                if (action === 'input-change') {
                  setSearchTerm(value);
                }
              }}
              onChange={handleSelectMedication}
              noOptionsMessage={({ inputValue }) => {
                if (!inputValue) return "Masukkan kata pencarian...";
                if (inputValue.length < 2) return "Masukkan minimal 2 huruf...";
                if (isLoading) return "Memuat data...";
                return "Tidak ada hasil";
              }}
              className="text-sm"
              classNames={{
                control: (state) => `border ${state.isFocused ? 'border-blue-500' : 'border-gray-300'} rounded-lg`,
                option: (state) => `${state.isFocused ? 'bg-blue-50' : 'bg-white'} cursor-pointer`,
              }}
              filterOption={null}
              formatOptionLabel={({ label, stock, price }) => (
                <div className="flex justify-between">
                  <span>{label}</span>
                  <span className={stock <= 0 ? 'text-red-500' : 'text-green-500'}>
                    {stock <= 0 ? 'Stok habis' : `Stok: ${stock}, Rp${price}`}
                  </span>
                </div>
              )}
            />
          </div>
          {type === 'medication' && tempMedication && (
            <div>
              <label className="block text-sm font-medium mb-1">Select Preset</label>
              <Select
                options={commonPresets[tempMedication.value]?.map((preset) => ({
                  value: preset,
                  label: `${preset.dosage} - ${preset.frequency} - ${preset.duration}`,
                }))}
                value={tempPreset ? { value: tempPreset, label: `${tempPreset.dosage} - ${tempPreset.frequency} - ${tempPreset.duration}` } : null}
                onChange={(selected) => setTempPreset(selected ? selected.value : null)}
                placeholder="Select a preset..."
                className="text-sm"
                classNames={{
                  control: (state) => `border ${state.isFocused ? 'border-blue-500' : 'border-gray-300'} rounded-lg`,
                  option: (state) => `${state.isFocused ? 'bg-blue-50' : 'bg-white'} cursor-pointer`,
                }}
              />
              <div className="mt-2 flex justify-end">
                <button
                  onClick={handleConfirmPreset}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded hover:bg-blue-700"
                  disabled={!tempPreset}
                >
                  Confirm
                </button>
              </div>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium mb-1">Selected {title}</label>
            <div className="flex flex-wrap gap-2 border rounded p-2 min-h-[40px]">
              {selectedItems.length > 0 ? (
                selectedItems.map((item, index) => (
                  <div key={index} className="bg-gray-200 px-3 py-1 rounded text-sm flex items-center gap-1">
                    <span>{formatSelectedMedication(item)}</span>
                    <button onClick={() => onRemoveItem(type, item)} className="text-gray-600 hover:text-gray-800 text-xs">x</button>
                  </div>
                ))
              ) : (
                <div className="text-sm text-gray-500">No items selected</div>
              )}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Recent {title}</label>
            <div className="flex flex-wrap gap-2 border rounded p-2 min-h-[40px]">
              {recentItems.length > 0 ? (
                recentItems.map((item, index) => (
                  <div
                    key={index}
                    className="bg-gray-200 px-3 py-1 rounded text-sm cursor-pointer hover:bg-gray-300"
                    onClick={() => onSelectItem(type, { value: item, label: item })}
                  >
                    {item}
                  </div>
                ))
              ) : (
                <div className="text-sm text-gray-500">No recent items</div>
              )}
            </div>
          </div>
          <div className="flex justify-end space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded hover:bg-gray-200"
            >
              Batal
            </button>
            <button
              onClick={() => onSave(type, medicationDetails)}
              disabled={loading}
              className={`px-4 py-2 text-sm font-medium text-white rounded ${
                loading ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {loading ? 'Menyimpan...' : 'Simpan'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// EditVitalsModal Component (unchanged)
const EditVitalsModal = ({ vitals, visitId, onSave, onClose }) => {
  const [tempVitals, setTempVitals] = useState({
    height: vitals.height.replace(' cm', '') || '',
    weight: vitals.weight.replace(' kg', '') || '',
    heartRate: vitals.heartRate.replace(' bpm', '') || '',
    bloodSugar: vitals.bloodSugar.replace(' mg/dl', '') || '',
    temperature: vitals.temperature.replace('° C', '') || '',
  });
  const [errorMessage, setErrorMessage] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleInputChange = (field, value) => {
    setTempVitals((prev) => ({ ...prev, [field]: value }));
    setErrorMessage(null);
  };

  const isFormValid = () => {
    return (
      tempVitals.height &&
      tempVitals.weight &&
      tempVitals.heartRate &&
      tempVitals.bloodSugar &&
      tempVitals.temperature
    );
  };

  const handleSubmit = async () => {
    try {
      setLoading(true);
      setErrorMessage(null);
      const token = localStorage.getItem('token');
      if (!visitId) {
        setErrorMessage('Tidak ada kunjungan untuk pasien ini. Silakan buat kunjungan terlebih dahulu.');
        return;
      }
      if (!isFormValid()) {
        setErrorMessage('Semua field wajib diisi.');
        return;
      }
      const payload = {
        visit_id: visitId,
        height: tempVitals.height,
        weight: tempVitals.weight,
        heart_rate: tempVitals.heartRate,
        blood_sugar: tempVitals.bloodSugar,
        temperature: tempVitals.temperature,
      };
      await axios.post('http://localhost:5000/api/medical/editvitals', payload, {
        headers: { Authorization: `Bearer ${token}` },
      });
      onSave({
        height: tempVitals.height ? `${tempVitals.height} cm` : 'Belum diisi',
        weight: tempVitals.weight ? `${tempVitals.weight} kg` : 'Belum diisi',
        heartRate: tempVitals.heartRate ? `${tempVitals.heartRate} bpm` : 'Belum diisi',
        bloodSugar: tempVitals.bloodSugar ? `${tempVitals.bloodSugar} mg/dl` : 'Belum diisi',
        temperature: tempVitals.temperature ? `${tempVitals.temperature}° C` : 'Belum diisi',
      });
      onClose();
    } catch (error) {
      console.error('Error saving vitals:', error);
      setErrorMessage('Gagal menyimpan vital signs. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-[rgba(0,0,0,0.5)] flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-96">
        <h2 className="text-xl font-bold mb-4">Edit Vital Signs</h2>
        {errorMessage && (
          <div className="text-red-500 text-sm mb-4">{errorMessage}</div>
        )}
        <div className="space-y-4">
          {[
            { label: 'Tinggi (cm)', field: 'height' },
            { label: 'Berat (kg)', field: 'weight' },
            { label: 'Detak Jantung (bpm)', field: 'heartRate' },
            { label: 'Gula Darah (mg/dl)', field: 'bloodSugar' },
            { label: 'Suhu (°C)', field: 'temperature' },
          ].map(({ label, field }) => (
            <div key={field}>
              <label className="block text-sm font-medium mb-1">{label}</label>
              <input
                type="number"
                value={tempVitals[field]}
                onChange={(e) => handleInputChange(field, e.target.value)}
                className="w-full px-3 py-2 border rounded"
              />
            </div>
          ))}
          <div className="flex justify-end space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded hover:bg-gray-200"
            >
              Batal
            </button>
            <button
              onClick={handleSubmit}
              disabled={loading || !isFormValid()}
              className={`px-4 py-2 text-sm font-medium text-white rounded ${
                loading || !isFormValid()
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {loading ? 'Menyimpan...' : 'Simpan'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// InputRM Component (aligned for patient display)
const InputRM = () => {
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [selectedPatientId, setSelectedPatientId] = useState(null);
  const [patients, setPatients] = useState([]);
  const [patientOptions, setPatientOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [searchTerm, setSearchTerm] = useState('');

  const [vitals, setVitals] = useState({
    height: 'Belum diisi',
    weight: 'Belum diisi',
    heartRate: 'Belum diisi',
    bloodSugar: 'Belum diisi',
    temperature: 'Belum diisi',
  });
  const [showEditVitalsModal, setShowEditVitalsModal] = useState(false);

  const [medicalRecord, setMedicalRecord] = useState({
    procedures: [],
    diagnoses: [],
    medications: [],
  });

  const [modalState, setModalState] = useState({
    procedure: { show: false, selected: [], recent: [] },
    diagnose: { show: false, selected: [], recent: [] },
    medication: { show: false, selected: [], recent: [], details: {} },
  });

  const [visitHistory, setVisitHistory] = useState([]);

  const updateModalState = useCallback((type, updates) => {
    setModalState((prev) => ({
      ...prev,
      [type]: { ...prev[type], ...updates },
    }));
  }, []);

  const handleSearchMedicalRecord = useCallback(async (type, term) => {
    if (term.length < 2) {
      return [];
    }
    try {
      const token = localStorage.getItem('token');
      let endpoint = '';
      switch (type) {
        case 'procedure':
          endpoint = `http://localhost:5000/api/medical/procedures/search?search=${term}`;
          break;
        case 'medication':
          endpoint = `http://localhost:5000/api/medical/medications/search?search=${term}`;
          break;
        case 'diagnose':
          endpoint = `http://localhost:5000/api/medical/diagnoses/search?search=${term}`;
          break;
        default:
          throw new Error('Tipe tidak valid');
      }
      const response = await axios.get(endpoint, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.data.success) {
        return response.data.data.map((item) => {
          if (type === 'diagnose') {
            return { value: `${item.code} - ${item.name}`, label: `${item.code} - ${item.name}`, id: item.id };
          }
          return { value: item.name, label: item.name, id: item.id, stock: item.stock, price: item.price };
        });
      }
      return [];
    } catch (error) {
      console.error(`Error searching ${type}:`, error);
      setError(`Gagal mencari ${type}`);
      return [];
    }
  }, []);

  const handleSaveMedicalRecord = useCallback(
    async (type, details = {}) => {
      try {
        setLoading(true);
        const token = localStorage.getItem('token');
        if (!token) {
          setError('Token autentikasi tidak ditemukan. Silakan login kembali.');
          return;
        }
        const payload = {
          visit_id: visitHistory[0]?.visit_id,
          items: modalState[type].selected.map((item) => ({
            name: item,
            ...(type === 'medication' && details[item]
              ? {
                  dosage: details[item].dosage,
                  frequency: details[item].frequency,
                  duration: details[item].duration,
                }
              : {}),
          })),
        };
        if (!payload.visit_id) {
          setError('Tidak ada kunjungan untuk pasien ini. Silakan buat kunjungan terlebih dahulu.');
          return;
        }
        const endpoint = `http://localhost:5000/api/medical/visit-${type}s`;
        const response = await axios.post(endpoint, payload, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (response.data.success) {
          updateModalState(type, { selected: [], show: false, details: {} });
          setMedicalRecord((prev) => ({
            ...prev,
            [`${type}s`]: payload.items.map((item) => item.name),
          }));
          await fetchPatientData(selectedPatientId);
        } else {
          setError(response.data.message || `Gagal menyimpan ${type}`);
        }
      } catch (error) {
        console.error(`Error saving ${type}:`, error);
        setError(error.response?.data?.message || `Gagal menyimpan ${type}`);
      } finally {
        setLoading(false);
      }
    },
    [visitHistory, modalState, selectedPatientId, updateModalState]
  );

  const handleSelectItem = useCallback(
    (type, item) => {
      if (!item) return;
      const selectedItems = modalState[type].selected;
      if (selectedItems.includes(item.value)) return;
      updateModalState(type, {
        selected: [...selectedItems, item.value],
        recent: [item.value, ...modalState[type].recent.filter((rec) => rec !== item.value)].slice(0, 10),
      });
    },
    [modalState, updateModalState]
  );

  const handleRemoveItem = useCallback(
    (type, item) => {
      updateModalState(type, {
        selected: modalState[type].selected.filter((i) => i !== item),
      });
      if (type === 'medication') {
        setModalState((prev) => {
          const newDetails = { ...prev.medication.details };
          delete newDetails[item];
          return { ...prev, medication: { ...prev.medication, details: newDetails } };
        });
      }
    },
    [modalState, updateModalState]
  );

  const fetchPatients = useCallback(async (date, search = '') => {
    try {
      setLoading(true);
      setError(null);
      const token = localStorage.getItem('token');
      if (!token) {
        setError('Token autentikasi tidak ditemukan. Silakan login kembali.');
        return;
      }
      const formattedDate = format(date, 'yyyy-MM-dd');
      const response = await axios.post(
        `http://localhost:5000/api/medical/patients/waiting`,
        { date: formattedDate, search },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (response.data.success && response.data.data) {
        const options = response.data.data.map((patient) => ({
          value: patient.no_rm,
          label: `${patient.nama_lengkap} (${patient.no_rm})`,
          patient: {
            id: patient.id,
            no_rm: patient.no_rm,
            name: patient.nama_lengkap,
            age: `${patient.umur} Tahun`,
            complaint: '',
            appointment_time: patient.appointment_time,
          },
        }));
        setPatientOptions(options);
        setPatients(options.map((option) => option.patient));
      } else {
        setError(response.data.message || 'Tidak ada pasien untuk tanggal ini.');
        setPatientOptions([]);
        setPatients([]);
      }
    } catch (error) {
      console.error('Error fetching waiting patients:', error);
      setError(error.response?.data?.message || 'Gagal mengambil data pasien. Silakan coba lagi.');
      setPatientOptions([]);
      setPatients([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handlePatientSelect = useCallback((selectedOption) => {
    if (!selectedOption) {
      setSelectedPatient(null);
      setSelectedPatientId(null);
      setVitals({
        height: 'Belum diisi',
        weight: 'Belum diisi',
        heartRate: 'Belum diisi',
        bloodSugar: 'Belum diisi',
        temperature: 'Belum diisi',
      });
      setMedicalRecord({ procedures: [], diagnoses: [], medications: [] });
      updateModalState('procedure', { selected: [], recent: [] });
      updateModalState('diagnose', { selected: [], recent: [] });
      updateModalState('medication', { selected: [], recent: [], details: {} });
      setVisitHistory([]);
      setError(null);
      return;
    }

    const patient = selectedOption.patient;
    setSelectedPatient(patient.name);
    setSelectedPatientId(patient.no_rm);
    setVitals({
      height: 'Belum diisi',
      weight: 'Belum diisi',
      heartRate: 'Belum diisi',
      bloodSugar: 'Belum diisi',
      temperature: 'Belum diisi',
    });
    setMedicalRecord({ procedures: [], diagnoses: [], medications: [] });
    updateModalState('procedure', { selected: [], recent: [] });
    updateModalState('diagnose', { selected: [], recent: [] });
    updateModalState('medication', { selected: [], recent: [], details: {} });
    setVisitHistory([]);
    setError(null);
    fetchPatientData(patient.no_rm);
  }, [updateModalState]);

  const fetchPatientData = useCallback(async (patientNoRM) => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const combinedResponse = await axios.get(`http://localhost:5000/api/medical/patients/${patientNoRM}/combined-data`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (combinedResponse.data.success && combinedResponse.data.data) {
        const { vitals: vitalData, procedures, diagnoses, medications } = combinedResponse.data.data;
        setVitals({
          height: vitalData?.height ? `${vitalData.height} cm` : 'Belum diisi',
          weight: vitalData?.weight ? `${vitalData.weight} kg` : 'Belum diisi',
          heartRate: vitalData?.heart_rate ? `${vitalData.heart_rate} bpm` : 'Belum diisi',
          bloodSugar: vitalData?.blood_sugar ? `${vitalData.blood_sugar} mg/dl` : 'Belum diisi',
          temperature: vitalData?.temperature ? `${vitalData.temperature}° C` : 'Belum diisi',
        });
        setMedicalRecord({
          procedures: procedures || [],
          diagnoses: diagnoses || [],
          medications: medications.map((m) => m.name) || [],
        });
        updateModalState('procedure', { selected: procedures || [] });
        updateModalState('diagnose', { selected: diagnoses || [] });
        updateModalState('medication', {
          selected: medications.map((m) => m.name) || [],
          details: medications.reduce(
            (acc, m) => ({
              ...acc,
              [m.name]: {
                dosage: m.dosage || '3x1',
                frequency: m.frequency || 'Setelah makan',
                duration: m.duration || '5 hari',
              },
            }),
            {}
          ),
        });
      } else {
        setError('Gagal mengambil data pasien: Data tidak ditemukan.');
      }

      const visitsResponse = await axios.get(`http://localhost:5000/api/medical/patients/${patientNoRM}/visits`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (visitsResponse.data.success && visitsResponse.data.data) {
        setVisitHistory(
          visitsResponse.data.data.map((visit) => {
            const visitDate = new Date(visit.visit_date);
            return {
              visit_id: visit.visit_id,
              month: format(visitDate, 'MMM'),
              day: format(visitDate, 'd'),
              year: format(visitDate, 'yyyy'),
              time: format(visitDate, 'HH:mm'),
              doctor: visit.doctor_name,
              specialty: visit.doctor_specialty,
              notes: visit.complaint || visit.notes,
            };
          })
        );
      } else {
        setVisitHistory([]);
      }
    } catch (error) {
      console.error('Error fetching patient data:', error);
      setError('Gagal mengambil data pasien');
      setVitals({
        height: 'Belum diisi',
        weight: 'Belum diisi',
        heartRate: 'Belum diisi',
        bloodSugar: 'Belum diisi',
        temperature: 'Belum diisi',
      });
    } finally {
      setLoading(false);
    }
  }, [updateModalState]);

  useEffect(() => {
    fetchPatients(selectedDate, searchTerm);
  }, [selectedDate, searchTerm, fetchPatients]);

  const activeModalType = ['procedure', 'diagnose', 'medication'].find((type) => modalState[type].show);

  return (
    <PageTemplate>
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Electronic Medical Record</h1>
        {error && <div className="text-red-500 text-sm mb-4">{error}</div>}
        <div className="grid grid-cols-[250px_1fr] gap-4">
          <div className="bg-gray-100 rounded-lg h-dvh">
            <div className="p-3 border-b border-gray-200">
              <div className="text-sm text-gray-500 mb-2">Filter by Date</div>
              <DatePicker
                selected={selectedDate}
                onChange={(date) => setSelectedDate(date)}
                dateFormat="dd/MM/yyyy"
                className="w-full px-3 py-2 border rounded text-sm"
                placeholderText="Pilih tanggal"
              />
              <div className="text-sm text-gray-500 mt-4 mb-2">Search</div>
              <Select
                isClearable
                isSearchable
                placeholder="Cari berdasarkan NIK atau nama (min. 3 huruf)..."
                options={patientOptions}
                onInputChange={(value, { action }) => {
                  if (action === 'input-change') {
                    setSearchTerm(value);
                  }
                }}
                onChange={handlePatientSelect}
                noOptionsMessage={({ inputValue }) => {
                  if (!inputValue) return "Masukkan kata pencarian...";
                  if (inputValue.length < 3) return "Masukkan minimal 3 huruf...";
                  if (loading) return "Memuat data...";
                  return "Tidak ada hasil";
                }}
                className="text-sm"
                classNames={{
                  control: (state) => `border ${state.isFocused ? 'border-blue-500' : 'border-gray-300'} rounded-lg`,
                  option: (state) => `${state.isFocused ? 'bg-blue-50' : 'bg-white'} cursor-pointer`,
                }}
                filterOption={null}
                inputValue={searchTerm}
              />
            </div>
            <div className="p-3">
              {loading ? (
                <div className="text-center py-4 text-gray-500">Memuat data...</div>
              ) : error && !patients.length ? (
                <div className="text-center py-4 text-red-500">{error}</div>
              ) : patients.length === 0 ? (
                <div className="text-center py-4 text-gray-500">Tidak ada pasien untuk tanggal ini</div>
              ) : (
                patients.map((patient, index) => (
                  <div
                    key={index}
                    className={`flex items-center p-2 rounded-md mb-2 cursor-pointer ${
                      selectedPatient === patient.name ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'
                    }`}
                    onClick={() => handlePatientSelect({ patient })}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${
                        selectedPatient === patient.name ? 'bg-white text-blue-600' : 'bg-gray-300 text-gray-800'
                      }`}
                    >
                      {patient.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-medium text-sm">{patient.name}</div>
                      <div
                        className={`text-xs ${
                          selectedPatient === patient.name ? 'text-blue-100' : 'text-gray-600'
                        }`}
                      >
                        {patient.no_rm} | {patient.appointment_time || 'No time'}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
          <div>
            {selectedPatient ? (
              <>
                <div className="bg-gray-200 p-4 mb-6 flex items-center rounded-lg">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 text-xl font-bold mr-4">
                    {selectedPatient.charAt(0)}
                  </div>
                  <div>
                    <div className="text-gray-600 text-sm">
                      {patients.find((p) => p.name === selectedPatient)?.no_rm || ''}
                    </div>
                    <div className="text-lg font-bold">{selectedPatient}</div>
                    <div className="text-sm">
                      {patients.find((p) => p.name === selectedPatient)?.age || ''}
                    </div>
                  </div>
                  <div className="ml-auto bg-blue-50 p-3 rounded-lg">
                    <div className="text-sm text-gray-600">Complaint:</div>
                    <div className="text-sm">
                      {visitHistory.length > 0 ? visitHistory[0].notes : 'Tidak ada keluhan'}
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-6">
                  <div className="col-span-1">
                    <h2 className="text-lg font-bold mb-4">Medical Record</h2>
                    {['procedure', 'diagnose', 'medication'].map((type) => (
                      <div
                        key={type}
                        className="bg-gray-100 p-4 rounded-lg mb-4 flex justify-between items-center border-1 border-gray-300"
                      >
                        <div className="flex-grow">
                          <div className="font-medium mb-3">
                            {type.charAt(0).toUpperCase() + type.slice(1)}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {medicalRecord[`${type}s`].length > 0 ? (
                              medicalRecord[`${type}s`].map((item, index) => (
                                <div
                                  key={index}
                                  className="bg-gray-200 px-3 py-1 rounded text-sm border-gray-300"
                                >
                                  {type === 'medication' && modalState.medication.details[item] ? (
                                    `${item} ${modalState.medication.details[item].dosage} - ${modalState.medication.details[item].frequency} - ${modalState.medication.details[item].duration}`
                                  ) : (
                                    item
                                  )}
                                </div>
                              ))
                            ) : (
                              <div className="text-sm text-gray-500">Tidak ada data {type}</div>
                            )}
                          </div>
                        </div>
                        <button
                          className="ml-4 bg-blue-100 p-2 rounded-full"
                          onClick={() => updateModalState(type, { show: true })}
                          disabled={visitHistory.length === 0}
                        >
                          <svg
                            className={`w-6 h-6 ${
                              visitHistory.length === 0 ? 'text-gray-400' : 'text-blue-600 font-bold'
                            }`}
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M9 5l7 7-7 7"
                            />
                          </svg>
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="col-span-1">
                    <h2 className="text-lg font-bold mb-4">Vitals</h2>
                    <div className="bg-gray-100 p-6 rounded-lg border-1 border-gray-300">
                      <div className="flex justify-between items-center mb-4 text-xs text-gray-500">
                        <div>
                          {visitHistory.length > 0
                            ? `${visitHistory[0].day} ${visitHistory[0].month} ${visitHistory[0].year} · ${visitHistory[0].time}`
                            : 'Tidak ada data'}
                        </div>
                        {visitHistory.length > 0 ? (
                          <button
                            className="bg-blue-100 text-blue-600 px-3 py-1 rounded-sm font-bold"
                            onClick={() => setShowEditVitalsModal(true)}
                          >
                            Edit
                          </button>
                        ) : (
                          <div className="text-sm text-gray-500">Belum ada kunjungan</div>
                        )}
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        {[
                          { label: 'Height', value: vitals.height },
                          { label: 'Heart Rate', value: vitals.heartRate },
                          { label: 'Weight', value: vitals.weight },
                          { label: 'Blood Sugar', value: vitals.bloodSugar },
                          { label: 'Temperature', value: vitals.temperature },
                        ].map(({ label, value }) => (
                          <div key={label}>
                            <div className="text-sm text-gray-500">{label}</div>
                            <div className="text-2xl font-bold">{value || 'N/A'}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                    {showEditVitalsModal && visitHistory.length > 0 && (
                      <EditVitalsModal
                        vitals={vitals}
                        visitId={visitHistory[0].visit_id}
                        onSave={setVitals}
                        onClose={() => setShowEditVitalsModal(false)}
                      />
                    )}
                    {activeModalType && (
                      <MedicalRecordModal
                        key={activeModalType}
                        type={activeModalType}
                        title={activeModalType.charAt(0).toUpperCase() + activeModalType.slice(1)}
                        show={modalState[activeModalType].show}
                        onClose={() => updateModalState(activeModalType, { show: false })}
                        onSave={handleSaveMedicalRecord}
                        selectedItems={modalState[activeModalType].selected}
                        recentItems={modalState[activeModalType].recent}
                        medicationDetails={modalState.medication.details}
                        onSearch={handleSearchMedicalRecord}
                        onSelectItem={handleSelectItem}
                        onRemoveItem={handleRemoveItem}
                        loading={loading}
                      />
                    )}
                  </div>
                  <div className="col-span-1">
                    <h2 className="text-lg font-bold mb-4">Visit History</h2>
                    <div className="relative">
                      <div className="absolute left-2 top-0 bottom-0 w-0.5 bg-blue-200"></div>
                      {visitHistory.length > 0 ? (
                        visitHistory.map((visit, index) => (
                          <div key={index} className="relative pl-8 mb-6">
                            <div
                              className={`absolute left-0 w-4 h-4 rounded-full ${
                                index === 0 ? 'bg-blue-500' : 'bg-gray-300'
                              }`}
                            ></div>
                            <div className="bg-white p-4 rounded-lg shadow-sm">
                              <div className="flex items-baseline mb-1">
                                <div className="text-sm text-gray-500">{visit.month}</div>
                                <div className="text-xl font-bold ml-1">{visit.day}</div>
                                <div className="text-xs text-gray-500 ml-1">{visit.time}</div>
                              </div>
                              <div className="font-medium">{visit.doctor}</div>
                              <div className="text-xs text-gray-500">{visit.specialty}</div>
                              <div className="mt-2 bg-gray-100 p-2 rounded text-xs">
                                {visit.notes}
                              </div>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-4 text-gray-500">Tidak ada riwayat kunjungan</div>
                      )}
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center p-8 bg-gray-50 rounded-lg">
                  <div className="text-gray-400 mb-2">Silakan pilih pasien dari daftar</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </PageTemplate>
  );
};

export default InputRM;