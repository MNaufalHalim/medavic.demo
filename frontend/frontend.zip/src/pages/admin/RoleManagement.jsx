import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Shield, Save, Plus, Edit2, X, Trash2 } from 'lucide-react';

const RoleManagement = () => {
  const navigate = useNavigate();
  const [roles, setRoles] = useState([]);
  const [menus, setMenus] = useState([]);
  const [selectedRole, setSelectedRole] = useState(null);
  const [privileges, setPrivileges] = useState({});
  const [hasChanges, setHasChanges] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState('create');
  const [roleForm, setRoleForm] = useState({ role_name: '', description: '' });
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    if (!user.role_id) {
      navigate('/login');
      return;
    }
    fetchRolesAndMenus();
  }, []);

  const fetchRolesAndMenus = async () => {
    try {
      const token = localStorage.getItem('token');
      const [rolesRes, menusRes] = await Promise.all([
        axios.get('http://localhost:5000/api/roles', {
          headers: { Authorization: `Bearer ${token}` }
        }),
        axios.get('http://localhost:5000/api/menus', {  // Changed from /api/menu to /api/menus
          headers: { Authorization: `Bearer ${token}` }
        })
      ]);
      setRoles(rolesRes.data.data);
      setMenus(menusRes.data.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const fetchPrivileges = async (roleId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`http://localhost:5000/api/roles/${roleId}/privilege`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      // Convert array to object for easier handling
      const privilegeObj = {};
      response.data.data.forEach(priv => {
        privilegeObj[priv.menu_id] = {
          can_view: priv.can_view === 1,
          can_create: priv.can_create === 1,
          can_edit: priv.can_edit === 1,
          can_delete: priv.can_delete === 1,
          can_access: priv.can_access === 1
        };
      });
      setPrivileges(privilegeObj);
    } catch (error) {
      console.error('Error fetching privileges:', error);
    }
  };

  const handleRoleSelect = (role) => {
    if (hasChanges) {
      if (!confirm('You have unsaved changes. Continue anyway?')) return;
    }
    setSelectedRole(role);
    fetchPrivileges(role.id);
    setHasChanges(false);
  };

  const handlePrivilegeChange = (menuId, privilege) => {
    setPrivileges(prev => ({
      ...prev,
      [menuId]: {
        ...(prev[menuId] || {}),
        [privilege]: !(prev[menuId]?.[privilege] || false)
      }
    }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    try {
      const token = localStorage.getItem('token');
      const privilegeArray = Object.entries(privileges).map(([menuId, privs]) => ({
        menu_id: parseInt(menuId),
        can_view: privs.can_view ? 1 : 0,
        can_create: privs.can_create ? 1 : 0,
        can_edit: privs.can_edit ? 1 : 0,
        can_delete: privs.can_delete ? 1 : 0,
        can_access: privs.can_access ? 1 : 0
      }));

      await axios.post(
        `http://localhost:5000/api/roles/${selectedRole.id}/privilege`,
        { privileges: privilegeArray },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setHasChanges(false);
      alert('Privileges saved successfully');
    } catch (error) {
      console.error('Error saving privileges:', error);
      alert('Error saving privileges');
    }
  };

  const handleSaveRole = async () => {
    try {
      const token = localStorage.getItem('token');
      if (modalMode === 'create') {
        await axios.post('http://localhost:5000/api/roles', roleForm, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } else {
        await axios.put(`http://localhost:5000/api/roles/${selectedRole.id}`, roleForm, {
          headers: { Authorization: `Bearer ${token}` }
        });
      }
      fetchRolesAndMenus();
      setShowModal(false);
      setRoleForm({ role_name: '', description: '' });
    } catch (error) {
      console.error('Error saving role:', error);
      alert('Error saving role');
    }
  };

  const handleDeleteRole = async (e, role) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this role?')) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/roles/${role.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchRolesAndMenus();
      if (selectedRole?.id === role.id) {
        setSelectedRole(null);
        setPrivileges({});
      }
    } catch (error) {
      console.error('Error deleting role:', error);
      alert('Error deleting role');
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Role & Privilege Management</h1>
      </div>

      <div className="flex gap-6">
        {/* Role List */}
        <div className="w-64 bg-white rounded-lg shadow">
          <div className="p-4 border-b flex justify-between items-center">
            <h2 className="font-semibold">Roles</h2>
            <button 
              onClick={() => {
                setModalMode('create');
                setRoleForm({ role_name: '', description: '' });
                setShowModal(true);
              }}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <Plus size={20} />
            </button>
          </div>
          
          <div className="p-2">
            {roles.map(role => (
              <div
                key={role.id}
                onClick={() => handleRoleSelect(role)}
                className={`p-3 rounded-lg cursor-pointer flex items-center justify-between ${
                  selectedRole?.id === role.id ? 'bg-blue-50' : 'hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Shield size={18} className="text-blue-600" />
                  <span>{role.role_name}</span>
                  {role.is_system === 1 && (
                    <span className="text-xs text-gray-500">(System)</span>
                  )}
                </div>
                {role.is_system !== 1 && (
                  <div className="flex gap-1">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setModalMode('edit');
                        setRoleForm({ role_name: role.role_name, description: role.description });
                        setSelectedRole(role);
                        setShowModal(true);
                      }}
                      className="p-1 hover:bg-gray-200 rounded"
                    >
                      <Edit2 size={14} />
                    </button>
                    <button 
                      onClick={(e) => handleDeleteRole(e, role)}
                      className="p-1 hover:bg-red-100 rounded text-red-600"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Privileges Table */}
        <div className="flex-1 bg-white rounded-lg shadow p-6">
          {selectedRole ? (
            <>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">{selectedRole.role_name} Privileges</h2>
                <button
                  onClick={handleSave}
                  disabled={!hasChanges}
                  className={`flex items-center gap-2 px-4 py-2 rounded ${
                    hasChanges 
                      ? 'bg-blue-600 text-white hover:bg-blue-700' 
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }`}
                >
                  <Save size={16} />
                  Save Changes
                </button>
              </div>

              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left p-3">Menu</th>
                    <th className="text-center p-3">View</th>
                    <th className="text-center p-3">Create</th>
                    <th className="text-center p-3">Edit</th>
                    <th className="text-center p-3">Delete</th>
                    <th className="text-center p-3">Access</th>
                  </tr>
                </thead>
                <tbody>
                  {menus.map(menu => (
                    <tr key={menu.id} className="border-t">
                      <td className="p-3">{menu.menu_name}</td>
                      {['view', 'create', 'edit', 'delete', 'access'].map(privilege => (
                        <td key={privilege} className="text-center p-3">
                          <input
                            type="checkbox"
                            checked={privileges[menu.id]?.[`can_${privilege}`] || false}
                            onChange={() => handlePrivilegeChange(menu.id, `can_${privilege}`)}
                            className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                          />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          ) : (
            <div className="text-center text-gray-500 py-12">
              Select a role to manage privileges
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg w-[480px]">
            <div className="p-6 border-b flex justify-between items-center">
              <h3 className="text-xl font-semibold">
                {modalMode === 'create' ? 'Add New Role' : 'Edit Role'}
              </h3>
              <button 
                onClick={() => setShowModal(false)}
                className="hover:bg-gray-100 p-2 rounded-full"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Role Name
                </label>
                <input
                  type="text"
                  value={roleForm.role_name}
                  onChange={e => setRoleForm({ ...roleForm, role_name: e.target.value })}
                  className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter role name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={roleForm.description}
                  onChange={e => setRoleForm({ ...roleForm, description: e.target.value })}
                  className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500 h-32"
                  placeholder="Enter role description"
                />
              </div>
            </div>

            <div className="p-6 border-t bg-gray-50 flex justify-end gap-3">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveRole}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                {modalMode === 'create' ? 'Create Role' : 'Update Role'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RoleManagement;
