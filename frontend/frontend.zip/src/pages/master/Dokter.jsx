import React from 'react';
import PageTemplate from '../../components/PageTemplate';

const Dokter = () => {
  return (
    <PageTemplate title="Data Dokter">
      {/* Dokter content */}
    </PageTemplate>
  );
};

export default Dokter;