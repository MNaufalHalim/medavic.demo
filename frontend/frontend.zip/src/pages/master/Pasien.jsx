import React from 'react';
import PageTemplate from '../../components/PageTemplate';

const Pasien = () => {
  return (
    <PageTemplate title="Data Pasien">
      {/* Pasien content */}
    </PageTemplate>
  );
};

export default Pasien;