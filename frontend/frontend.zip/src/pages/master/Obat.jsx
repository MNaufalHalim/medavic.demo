import React from 'react';
import PageTemplate from '../../components/PageTemplate';

const Obat = () => {
  return (
    <PageTemplate title="Data Obat">
      {/* Obat content */}
    </PageTemplate>
  );
};

export default Obat;