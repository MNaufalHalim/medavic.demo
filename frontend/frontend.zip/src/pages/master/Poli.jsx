import React from 'react';
import PageTemplate from '../../components/PageTemplate';

const Poli = () => {
  return (
    <PageTemplate title="Data Poli">
      {/* Poli content */}
    </PageTemplate>
  );
};

export default Poli;