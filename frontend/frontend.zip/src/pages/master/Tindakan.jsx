import React from 'react';
import PageTemplate from '../../components/PageTemplate';

const Tindakan = () => {
  return (
    <PageTemplate title="Data Tindakan">
      {/* Tindakan content */}
    </PageTemplate>
  );
};

export default Tindakan;