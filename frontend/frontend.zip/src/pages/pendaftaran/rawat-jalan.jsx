import React, { useState, useEffect } from 'react';
import { format, addDays, startOfToday } from 'date-fns';
import { id } from 'date-fns/locale';
import axios from 'axios';
import Select from 'react-select';
import { X } from 'lucide-react';
import PageTemplate from '../../components/PageTemplate';

const todayName = format(new Date(), 'EEEE').toLowerCase();

const RawatJalan = () => {
  const getAvailableDoctors = (currentSectionIdx) => {
    return doctors.filter(doctor => 
      !selectedDoctors.some((selectedDoc, idx) => 
        idx !== currentSectionIdx && selectedDoc && selectedDoc.id === doctor.id
      )
    );
  };

  const getDoctorStatusToday = (doctor) => {
    if (!doctor || !Array.isArray(doctor.schedule)) return "not available";
  
    const dayName = todayName;
  
    return doctor.schedule.some(
      (sch) => sch.day_of_week === dayName && sch.is_active
    )
      ? "available"
      : "not available";
  };

  const [dateRange, setDateRange] = useState({
    start: startOfToday(),
    end: addDays(startOfToday(), 6),
  });
  const [appointments, setAppointments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState(null);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedAppointment, setEditedAppointment] = useState(null);
  const [doctors, setDoctors] = useState([]);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [confirmAction, setConfirmAction] = useState(null);
  const [patientOptions, setPatientOptions] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showNewPatientForm, setShowNewPatientForm] = useState(false);
  const [selectedDoctors, setSelectedDoctors] = useState([null, null, null]);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [now, setNow] = useState(new Date());
  const [showDoctorModal, setShowDoctorModal] = useState(false);
  const [selectedSection, setSelectedSection] = useState(null);
  const [doctorSearchTerm, setDoctorSearchTerm] = useState('');
  const [newAppointment, setNewAppointment] = useState({
    no_rm: '',
    nik: '',
    nama_lengkap: '',
    tanggal_lahir: format(new Date(), 'yyyy-MM-dd'),
    jenis_kelamin: 'L',
    alamat: '',
    no_telepon: '',
    email: '',
    doctorId: '',
    doctor: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    time: '09:00',
    type: 'Konsultasi',
    status: 'scheduled',
    notes: '',
    poli: 'umum',
    height: '',
    weight: '',
    heart_rate: '',
    blood_sugar: '',
    temperature: '',
    complaint: ''
  });

  const timeSlots = Array.from({ length: 9 }, (_, i) => ({
    time: format(new Date().setHours(9 + i, 0), 'HH:mm'),
    label: format(new Date().setHours(9 + i, 0), 'HH:mm'),
  }));

  const getTimeGroup = (time) => {
    const hour = new Date().getHours();
    const timeHour = parseInt(time.split(':')[0]);
    return hour === timeHour;
  };

  const isDoctorAvailable = (doctorId, date, time) => {
    const doctor = doctors.find(d => d.id === doctorId);
    if (!doctor || !Array.isArray(doctor.schedule)) return false;
  
    const dayName = format(date, 'EEEE').toLowerCase();
  
    return doctor.schedule.some(schedule => {
      if (!schedule) return false;
      if (schedule.day_of_week !== dayName) return false;
      if (schedule.is_active === false) return false;
      
      if (!schedule.start_time || !schedule.end_time) return false;
      
      const startTime = schedule.start_time.substring(0, 5);
      const endTime = schedule.end_time.substring(0, 5);
      
      return time >= startTime && time <= endTime;
    });
  };

  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const date = addDays(dateRange.start, i);
    return {
      date,
      dayName: format(date, 'EEEE', { locale: id }),
      dayDate: format(date, 'd MMM', { locale: id }),
      fullDate: format(date, 'yyyy-MM-dd'),
    };
  });

  const checkSlotStatus = (slot, doctor, date) => {
    // console.log('Checking Slot Status:', {
    //   slotTime: slot.time,
    //   doctorId: doctor?.id,
    //   doctorName: doctor?.name,
    //   date: date,
    // });

    if (!doctor) {
      return { isAvailable: false, isBreakTime: false, existingAppointment: null };
    }
  
    const time = slot.time;
    const formattedDate = format(date, 'yyyy-MM-dd');
  
    const isBreakTime = time === '12:00';
    const isAvailable = isDoctorAvailable(doctor.id, date, time);
    const existingAppointment = appointments.find(
      app => Number(app.doctorId) === Number(doctor.id) && 
             app.date === formattedDate && 
             app.time === time
    );
  
    const result = { isAvailable, isBreakTime, existingAppointment };
    // console.log('Slot Status Result:', result);
    return result;
  };

  const handleSlotClick = (time, date) => {
    setModalType('new');
    setShowModal(true);
    setNewAppointment({
      no_rm: '',
      nik: '',
      nama_lengkap: '',
      tanggal_lahir: format(new Date(), 'yyyy-MM-dd'),
      jenis_kelamin: 'L',
      alamat: '',
      no_telepon: '',
      email: '',
      doctorId: '',
      doctor: '',
      date: date,
      time: time,
      type: 'Konsultasi',
      status: 'scheduled',
      notes: '',
      poli: 'umum',
      height: '',
      weight: '',
      heart_rate: '',
      blood_sugar: '',
      temperature: '',
      complaint: ''
    });
  };

  const handleAppointmentClick = (appointment) => {
    setSelectedAppointment(appointment);
    setModalType('detail');
    setShowModal(true);
  };

  useEffect(() => {
    fetchAppointments();
    fetchDoctors();
  }, [dateRange]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  const fetchAppointments = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/rm/appointments', {
        headers: { Authorization: `Bearer ${token}` },
        params: {
          start_date: format(dateRange.start, 'yyyy-MM-dd'),
          end_date: format(dateRange.end, 'yyyy-MM-dd'),
        },
      });
      console.log('API Response for Appointments:', response.data);
      if (response.data.status === 'success') {
        const fetchedAppointments = response.data.data.map((apt) => {
          const mappedAppointment = {
            appointment_code: apt.appointment_code,
            patientId: apt.patient_no_rm,
            patientName: apt.patient_name,
            doctorId: apt.doctor_id, // Map doctor_id to doctorId
            doctor: apt.doctor || 'Unknown Doctor', // Fallback if doctor name is missing
            date: format(new Date(apt.appointment_date), 'yyyy-MM-dd'),
            time: apt.appointment_time.substring(0, 5),
            type: apt.type,
            status: apt.status,
            notes: apt.notes || '',
            poli: apt.poli || 'umum',
          };
          console.log('Mapped Appointment:', mappedAppointment);
          return mappedAppointment;
        });
        console.log('Setting Appointments State:', fetchedAppointments);
        setAppointments(fetchedAppointments);
      } else {
        console.error('Failed to fetch appointments:', response.data.message);
        setAppointments([]);
      }
    } catch (error) {
      console.error('Error fetching appointments:', error);
      setAppointments([]);
    }
  };

  const fetchDoctors = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/master/doctors', {
        headers: { Authorization: `Bearer ${token}` },
      });
  
      if (response.data.status === 'success') {
        const doctorsWithScheduleObjects = response.data.data.map(doctor => {
          if (Array.isArray(doctor.schedule) && typeof doctor.schedule[0] === 'string') {
            return {
              ...doctor,
              schedule: doctor.schedule.map(day => ({
                day_of_week: day.toLowerCase(),
                start_time: '09:00',
                end_time: '17:00',
                is_active: true,
              }))
            };
          }
          return doctor;
        });
        console.log('Fetched Doctors:', doctorsWithScheduleObjects);
        setDoctors(doctorsWithScheduleObjects);
      }
    } catch (error) {
      console.error('Error fetching doctors:', error);
    }
  };

  const fetchDoctorSchedule = async (doctorId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/master/doctor-schedules', {
        headers: { Authorization: `Bearer ${token}` },
        params: { doctor_id: doctorId }
      });
      if (response.data.status === 'success') {
        const formattedSchedule = [];
        Object.entries(response.data.data).forEach(([day, timeSlots]) => {
          timeSlots.forEach(slot => {
            formattedSchedule.push({
              day_of_week: day.toLowerCase(),
              start_time: slot.start_time.substring(0, 5),
              end_time: slot.end_time.substring(0, 5),
              is_active: true,
              id: slot.id
            });
          });
        });
        setDoctors(prevDoctors => prevDoctors.map(doc => 
          doc.id === doctorId ? { ...doc, schedule: formattedSchedule } : doc
        ));
      }
    } catch (error) {
      console.error('Error fetching doctor schedule:', error);
    }
  };

  const handleSelectDoctor = (doctorId, sectionIdx) => {
    const fullDoctorData = doctors.find(d => d.id === doctorId);
    if (fullDoctorData) {
      setSelectedDoctors(prev => {
        const newArr = [...prev];
        newArr[sectionIdx] = fullDoctorData;
        return newArr;
      });
      fetchDoctorSchedule(doctorId);
    }
  };

  const handleCreateAppointment = async () => {
    try {
      const token = localStorage.getItem('token');
      let appointmentData;
      let finalPatientNoRm = selectedPatient?.no_rm;

      console.log('Creating Appointment with:', { selectedPatient, showNewPatientForm, newAppointment });

      if (!selectedPatient && showNewPatientForm) {
        const patientData = {
          nik: newAppointment.nik,
          nama_lengkap: newAppointment.nama_lengkap,
          tanggal_lahir: newAppointment.tanggal_lahir,
          jenis_kelamin: newAppointment.jenis_kelamin,
          alamat: newAppointment.alamat,
          no_telepon: newAppointment.no_telepon,
          email: newAppointment.email
        };
        const patientResponse = await axios.post('http://localhost:5000/api/rm/register', patientData, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (patientResponse.data.status !== 'success') {
          throw new Error('Failed to register patient');
        }
        finalPatientNoRm = patientResponse.data.data.no_rm;
        console.log('Registered new patient with no_rm:', finalPatientNoRm);
      } else if (selectedPatient) {
        finalPatientNoRm = selectedPatient.no_rm;
      } else {
        throw new Error('No patient selected or registered');
      }

      if (!finalPatientNoRm) {
        throw new Error('No patient selected or registered');
      }

      if (!newAppointment.doctorId) {
        throw new Error('No doctor selected');
      }

      appointmentData = {
        patient_no_rm: finalPatientNoRm,
        doctor_id: Number(newAppointment.doctorId), // Ensure doctorId is a number
        appointment_date: newAppointment.date,
        appointment_time: newAppointment.time,
        type: newAppointment.type,
        notes: newAppointment.notes,
        poli: newAppointment.poli,
        height: newAppointment.height,
        weight: newAppointment.weight,
        heart_rate: newAppointment.heart_rate,
        blood_sugar: newAppointment.blood_sugar,
        temperature: newAppointment.temperature,
        complaint: newAppointment.complaint
      };

      console.log('Sending Appointment Data:', appointmentData);
      const response = await axios.post('http://localhost:5000/api/rm/appointments', appointmentData, {
        headers: { Authorization: `Bearer ${token}` }
      });
      console.log('Create Appointment Response:', response.data);

      if (response.data.status === 'success') {
        await fetchAppointments(); // Refresh appointments to include the new one
        console.log('Appointments Refreshed After Creation');
        setShowModal(false);
        setSelectedPatient(null);
        setShowNewPatientForm(false);
        setNewAppointment({
          no_rm: '',
          nik: '',
          nama_lengkap: '',
          tanggal_lahir: format(new Date(), 'yyyy-MM-dd'),
          jenis_kelamin: 'L',
          alamat: '',
          no_telepon: '',
          email: '',
          doctorId: '',
          doctor: '',
          date: format(new Date(), 'yyyy-MM-dd'),
          time: '09:00',
          type: 'Konsultasi',
          status: 'scheduled',
          notes: '',
          poli: 'umum',
          height: '',
          weight: '',
          heart_rate: '',
          blood_sugar: '',
          temperature: '',
          complaint: ''
        });
      }
    } catch (error) {
      console.error('Error creating appointment:', error);
      alert('Failed to create appointment: ' + error.message);
    }
  };

  const handleUpdateAppointment = async () => {
    try {
      const token = localStorage.getItem('token');
      const appointmentData = {
        doctor_id: Number(editedAppointment.doctorId), // Ensure doctorId is a number
        appointment_date: editedAppointment.date,
        appointment_time: editedAppointment.time,
        type: editedAppointment.type,
        status: editedAppointment.status,
        notes: editedAppointment.notes,
        poli: editedAppointment.poli,
      };

      console.log('Updating appointment with data:', appointmentData);

      const response = await axios.put(
        `http://localhost:5000/api/rm/appointments/${selectedAppointment.appointment_code}`,
        appointmentData,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      console.log('Update Appointment Response:', response.data);

      if (response.data.status === 'success') {
        await fetchAppointments(); // Refresh appointments to reflect changes
        setShowModal(false);
        setIsEditing(false);
        setEditedAppointment(null);
      } else {
        throw new Error(response.data.message || 'Failed to update appointment');
      }
    } catch (error) {
      console.error('Error updating appointment:', error);
      alert('Failed to update appointment: ' + error.message);
    }
  };

  const handleDeleteAppointment = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/rm/appointments/${selectedAppointment.appointment_code}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      await fetchAppointments();
      setShowModal(false);
    } catch (error) {
      console.error('Error deleting appointment:', error);
      alert('Failed to delete appointment: ' + error.message);
    }
  };

  const handleAddClick = () => {
    setModalType('new');
    setShowModal(true);
    setNewAppointment({
      no_rm: '',
      nik: '',
      nama_lengkap: '',
      tanggal_lahir: format(new Date(), 'yyyy-MM-dd'),
      jenis_kelamin: 'L',
      alamat: '',
      no_telepon: '',
      email: '',
      doctorId: '',
      doctor: '',
      date: format(new Date(), 'yyyy-MM-dd'),
      time: '09:00',
      type: 'Konsultasi',
      status: 'scheduled',
      notes: '',
      poli: 'umum',
      height: '',
      weight: '',
      heart_rate: '',
      blood_sugar: '',
      temperature: '',
      complaint: ''
    });
  };

  const handleEditClick = () => {
    setIsEditing(true);
    setEditedAppointment({ ...selectedAppointment });
  };

  const handleDeleteClick = () => {
    setConfirmAction(() => async () => {
      await handleDeleteAppointment();
      setShowConfirmModal(false);
      setShowModal(false);
    });
    setShowConfirmModal(true);
  };

  const handleEditCancel = () => {
    setIsEditing(false);
    setEditedAppointment(null);
  };

  const handleEditSubmit = () => {
    setConfirmAction(() => async () => {
      await handleUpdateAppointment();
      setIsEditing(false);
      setEditedAppointment(null);
      setShowConfirmModal(false);
      setShowModal(false);
    });
    setShowConfirmModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setIsEditing(false);
    setEditedAppointment(null);
    setModalType(null);
    setSelectedAppointment(null);
    setSelectedPatient(null);
    setShowNewPatientForm(false);
    setPatientOptions([]);
    setNewAppointment({
      no_rm: '',
      nik: '',
      nama_lengkap: '',
      tanggal_lahir: format(new Date(), 'yyyy-MM-dd'),
      jenis_kelamin: 'L',
      alamat: '',
      no_telepon: '',
      email: '',
      doctorId: '',
      doctor: '',
      date: format(new Date(), 'yyyy-MM-dd'),
      time: '09:00',
      type: 'Konsultasi',
      status: 'scheduled',
      notes: '',
      poli: 'umum',
      height: '',
      weight: '',
      heart_rate: '',
      blood_sugar: '',
      temperature: '',
      complaint: ''
    });
  };

  const highlightMatch = (text, search) => {
    if (!text) return '';
    if (!search || search.length < 3) return text;
    
    const escapedSearch = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedSearch})`, 'gi');
    const parts = String(text).split(regex);
    
    return (
      <span>
        {parts.filter(part => part).map((part, i) => 
          regex.test(part) ? (
            <span key={i} className="bg-yellow-200">{part}</span>
          ) : (
            <span key={i}>{part}</span>
          )
        )}
      </span>
    );
  };

  const searchPatients = async (searchTerm) => {
    if (!searchTerm || searchTerm.length < 3) {
      setPatientOptions([]);
      return;
    }
  
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/rm/search', {
        headers: { Authorization: `Bearer ${token}` },
        params: { keyword: searchTerm }
      });
  
      if (response.data.status === 'success') {
        const options = response.data.data.map(patient => {
          const birthDate = new Date(patient.tanggal_lahir);
          const today = new Date();
          const age = today.getFullYear() - birthDate.getFullYear();
          
          return {
            value: patient.no_rm,
            label: (
              <div className="flex items-center gap-3 py-1">
                <div className={`w-8 h-8 rounded-full ${patient.jenis_kelamin === 'L' ? 'bg-blue-100 text-blue-600' : 'bg-pink-100 text-pink-600'} flex items-center justify-center font-medium text-lg`}>
                  {patient.jenis_kelamin}
                </div>
                <div>
                  <div className="font-medium">
                    {highlightMatch(patient.nama_lengkap, searchTerm)}
                  </div>
                  <div className="text-sm text-gray-500">
                    {highlightMatch(patient.nik, searchTerm)} • {age} tahun
                  </div>
                </div>
              </div>
            ),
            data: patient,
            age
          };
        });
        
        const finalOptions = [
          ...options,
          {
            value: 'new',
            label: (
              <div className="text-center py-2">
                <button className="text-blue-600 hover:text-blue-700 font-medium">
                  + Tambah Pasien Baru
                </button>
              </div>
            ),
            isDisabled: false
          }
        ];
        
        setPatientOptions(finalOptions);
      }
    } catch (error) {
      console.error('Error searching patients:', error);
      setPatientOptions([]);
    }
  };

  const handlePatientSelect = (selected) => {
    if (selected?.value === 'new') {
      setShowNewPatientForm(true);
      setSelectedPatient(null);
      setNewAppointment(prev => ({
        ...prev,
        no_rm: '',
        nik: '',
        nama_lengkap: '',
        tanggal_lahir: format(new Date(), 'yyyy-MM-dd'),
        jenis_kelamin: 'L',
        alamat: '',
        no_telepon: '',
        email: ''
      }));
      return;
    }
  
    if (selected) {
      setSelectedPatient(selected.data);
      setShowNewPatientForm(false);
      setNewAppointment(prev => ({
        ...prev,
        no_rm: selected.value,
        nik: selected.data.nik,
        nama_lengkap: selected.data.nama_lengkap,
        tanggal_lahir: selected.data.tanggal_lahir,
        jenis_kelamin: selected.data.jenis_kelamin,
        alamat: selected.data.alamat,
        no_telepon: selected.data.no_telepon,
        email: selected.data.email
      }));
    } else {
      setSelectedPatient(null);
      setNewAppointment(prev => ({
        ...prev,
        no_rm: ''
      }));
    }
  };

  return (
    <PageTemplate>
      <div className="">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Jadwal Kunjungan</h1>
            <p className="text-gray-500 mt-1">
              {format(dateRange.start, 'EEEE', { locale: id })}, {format(dateRange.start, 'dd MMM yyyy', { locale: id })} - {format(dateRange.end, 'EEEE', { locale: id })}, {format(dateRange.end, 'dd MMM yyyy', { locale: id })}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <button 
              className="bg-white px-4 py-2 rounded-lg shadow hover:bg-gray-50 flex items-center gap-2 text-gray-700"
              onClick={(e) => {
                const datePicker = e.currentTarget.querySelector('input[type="date"]');
                datePicker.showPicker();
              }}
            >
              <svg 
                className="w-5 h-5 text-gray-500" 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
                fillRule="evenodd"
                clipRule="evenodd"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <span>{format(dateRange.start, 'd MMM yyyy', { locale: id })}</span>
              <input
                type="date"
                value={format(dateRange.start, 'yyyy-MM-dd')}
                onChange={(e) => {
                  const newStart = new Date(e.target.value);
                  setDateRange({
                    start: newStart,
                    end: addDays(newStart, 6)
                  });
                }}
                className="absolute opacity-0 w-0 h-0"
              />
            </button>
            <button onClick={handleAddClick} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg font-medium shadow-sm">
              + Tambah Kunjungan
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-300 overflow-x-auto">
          <div className="min-w-[700px] grid grid-cols-[80px_repeat(3,1fr)] border-b border-gray-300">
            <div className="p-4 border-r border-gray-300">GMT +07:00</div>
            {[0, 1, 2].map((sectionIdx) => {
              const doctor = selectedDoctors[sectionIdx];
              return (
                <div
                  key={sectionIdx}
                  className={`${sectionIdx !== 2 ? 'border-r border-gray-300' : ''}`}
                >
                  <div className="relative">
                    <button
                      onClick={() => {
                        setSelectedSection(sectionIdx);
                        setShowDoctorModal(!showDoctorModal);
                      }}
                      className={`w-full p-4 ${doctor ? 'bg-white' : 'border-2 border-dashed border-gray-300'} rounded-lg hover:border-gray-400 transition-colors`}
                    >
                      {doctor ? (
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-medium text-xl shrink-0">
                            {doctor.name.charAt(0)}
                          </div>
                          <div className="flex flex-col items-start flex-1">
                            <span className="font-medium text-gray-900">Dr. {doctor.name}</span>
                            <span className="text-sm text-gray-500">
                              {doctor.specialization || 'Spesialis Umum'}
                            </span>
                            <span className="text-sm text-gray-500 mt-1">
                              Today's Appointment - {
                                appointments.filter(apt => 
                                  Number(apt.doctorId) === Number(doctor.id) && 
                                  apt.date === format(dateRange.start, 'yyyy-MM-dd')
                                ).length || 0
                              } Patient
                            </span>
                          </div>
                          <div
                            onClick={(e) => {
                              e.stopPropagation();
                              const newDoctors = [...selectedDoctors];
                              newDoctors[sectionIdx] = null;
                              setSelectedDoctors(newDoctors);
                            }}
                            className="text-gray-400 hover:text-gray-600 cursor-pointer"
                          >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-gray-500 justify-center py-2">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                          </svg>
                          <span>Pilih Dokter</span>
                        </div>
                      )}
                    </button>

                    {showDoctorModal && selectedSection === sectionIdx && (
                      <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg border border-gray-200 shadow-lg z-50 max-h-[300px] overflow-y-auto">
                        <div className="p-2">
                          <input
                            type="text"
                            value={doctorSearchTerm}
                            onChange={(e) => setDoctorSearchTerm(e.target.value)}
                            placeholder="Cari dokter..."
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                        </div>
                        <div className="divide-y divide-gray-100">
                          {getAvailableDoctors(selectedSection)
                            .filter(d => d.name.toLowerCase().includes(doctorSearchTerm.toLowerCase()))
                            .map(doctor => (
                              <div
                                key={doctor.id}
                                onClick={() => {
                                  handleSelectDoctor(doctor.id, selectedSection);
                                  setShowDoctorModal(false);
                                  setDoctorSearchTerm('');
                                }}
                                className="w-full px-4 py-2 text-left hover:bg-gray-50 flex items-center gap-3 cursor-pointer"
                              >
                                <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-medium">
                                  {doctor.name.charAt(0)}
                                </div>
                                <div>
                                  <div className="font-medium text-gray-900">
                                    Dr. {doctor.name}
                                  </div>
                                  <div className="text-sm text-gray-500">
                                    {doctor.specialization || 'Spesialis Umum'}
                                  </div>
                                  <div className={`text-xs mt-1 ${getDoctorStatusToday(doctor) === "available" ? "text-green-600" : "text-red-500"}`}>
                                    {getDoctorStatusToday(doctor)}
                                  </div>
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-[80px_repeat(3,1fr)]">
            <div className="border-r border-gray-300">
              {timeSlots.map((slot, idx) => (
                <div
                  key={idx}
                  className={`h-20 p-4 border-b border-gray-300 text-sm text-gray-500 ${
                    slot.time === '12:00' ? 'bg-gray-50' : ''
                  }`}
                >
                  {slot.time}
                </div>
              ))}
            </div>

            {[0, 1, 2].map((sectionIdx) => {
              const doctor = selectedDoctors[sectionIdx];
              return (
                <div key={sectionIdx} className={`${sectionIdx !== 2 ? 'border-r border-gray-300' : ''}`}>
                  {timeSlots.map((slot, timeIdx) => {
                    const { isAvailable, isBreakTime, existingAppointment } = checkSlotStatus(slot, doctor, dateRange.start);

                    return (
                      <div
                        key={timeIdx}
                        className={`h-20 border-b border-gray-300 relative ${
                          !doctor
                            ? 'bg-gray-50/30'
                            : isBreakTime
                            ? 'bg-orange-50'
                            : !isAvailable
                            ? 'bg-gray-100'
                            : !existingAppointment
                            ? 'group hover:bg-blue-50/30'
                            : ''
                        }`}
                      >
                        {isBreakTime && (
                          <div className="absolute inset-0 flex items-center justify-center z-30">
                            <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_10px,#fef3c7_10px,#fef3c7_20px)]"></div>
                            <span className="text-xs text-amber-600 bg-white/80 px-2 py-1 rounded-full z-40">
                              BREAK TIME
                            </span>
                          </div>
                        )}
                        
                        {!isBreakTime && !isAvailable && (
                          <div className="absolute inset-0 flex items-center justify-center z-20">
                            <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_10px,#f3f4f6_10px,#f3f4f6_20px)]"></div>
                            <span className="text-xs text-gray-500 bg-white/80 px-2 py-1 rounded-full z-30">
                              NOT AVAILABLE
                            </span>
                          </div>
                        )}

                        {!isBreakTime && isAvailable && existingAppointment && (
                          <button
                            onClick={() => handleAppointmentClick(existingAppointment)}
                            className="absolute inset-0 z-10 p-3 text-left"
                          >
                            <div className="bg-blue-50 rounded-lg p-2 h-full flex flex-col">
                              <span className="font-medium text-blue-700 truncate">
                                {existingAppointment.patientName}
                              </span>
                              <span className="text-sm text-blue-500">
                                {existingAppointment.type}
                              </span>
                            </div>
                          </button>
                        )}
                        
                        {!isBreakTime && isAvailable && !existingAppointment && doctor && (
                          <button
                            onClick={() => {
                              setModalType('new');
                              setShowModal(true);
                              setNewAppointment(prev => ({
                                ...prev,
                                doctorId: doctor.id,
                                doctor: doctor.name,
                                date: format(dateRange.start, 'yyyy-MM-dd'),
                                time: slot.time,
                                type: 'Konsultasi',
                                status: 'scheduled',
                                poli: 'umum',
                                height: '',
                                weight: '',
                                heart_rate: '',
                                blood_sugar: '',
                                temperature: '',
                                complaint: ''
                              }));
                            }}
                            className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200 z-5"
                          >
                            <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center hover:bg-blue-200">
                              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                              </svg>
                            </div>
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-[rgba(0,0,0,0.5)] flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-lg">
            <div className="border-b px-6 py-4 flex justify-between items-center border-gray-400">
              <h3 className="text-xl font-semibold text-gray-900">
                {modalType === 'new' ? 'Tambah Kunjungan' : `Detail Kunjungan ${isEditing ? '(Edit Mode)' : ''}`}
              </h3>
              <button onClick={handleCloseModal} className="text-gray-400 hover:text-gray-500">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="px-6 py-4">
              {modalType === 'new' && (
                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-2">Cari Pasien</h4>
                    <div className="flex gap-4 items-start">
                      <div className="flex-1">
                        <Select
                          isClearable
                          isSearchable
                          placeholder="Cari berdasarkan NIK atau nama (min. 3 huruf)..."
                          options={patientOptions}
                          onInputChange={(value, { action }) => {
                            if (action === 'input-change') {
                              searchPatients(value);
                            }
                          }}
                          onChange={handlePatientSelect}
                          noOptionsMessage={({ inputValue }) => {
                            if (!inputValue) return "Masukkan kata pencarian...";
                            if (inputValue.length < 3) return "Masukkan minimal 3 huruf...";
                            return "Tidak ada hasil";
                          }}
                          className="text-sm"
                          classNames={{
                            control: (state) => 
                              `border ${state.isFocused ? 'border-blue-500' : 'border-gray-300'} rounded-lg`,
                            option: (state) =>
                              `${state.isFocused ? 'bg-blue-50' : 'bg-white'} cursor-pointer`,
                          }}
                          filterOption={null}
                          inputValue={undefined}
                        />
                      </div>
                    </div>
                  </div>

                  {selectedPatient && (
                    <div className="space-y-4 bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium text-gray-900">Detail Pasien</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">NIK</h4>
                          <p className="mt-1 text-gray-900">{selectedPatient.nik}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Nama Lengkap</h4>
                          <p className="mt-1 text-gray-900">{selectedPatient.nama_lengkap}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Tanggal Lahir</h4>
                          <p className="mt-1 text-gray-900">
                            {format(new Date(selectedPatient.tanggal_lahir), 'dd MMM yyyy')}
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Jenis Kelamin</h4>
                          <p className="mt-1 text-gray-900">
                            {selectedPatient.jenis_kelamin === 'L' ? 'Laki-laki' : 'Perempuan'}
                          </p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Alamat</h4>
                          <p className="mt-1 text-gray-900">{selectedPatient.alamat}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">No. Telepon</h4>
                          <p className="mt-1 text-gray-900">{selectedPatient.no_telepon}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {!selectedPatient && showNewPatientForm && (
                    <div className="space-y-4">
                      <h4 className="font-medium text-gray-900">Data Pasien Baru</h4>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">NIK</h4>
                        <input
                          type="text"
                          value={newAppointment.nik}
                          onChange={(e) =>
                            setNewAppointment((prev) => ({ ...prev, nik: e.target.value }))
                          }
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="Masukkan NIK"
                        />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Nama Lengkap</h4>
                        <input
                          type="text"
                          value={newAppointment.nama_lengkap}
                          onChange={(e) =>
                            setNewAppointment((prev) => ({
                              ...prev,
                              nama_lengkap: e.target.value,
                            }))
                          }
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="Masukkan nama lengkap"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Tanggal Lahir</h4>
                          <input
                            type="date"
                            value={newAppointment.tanggal_lahir}
                            onChange={(e) =>
                              setNewAppointment((prev) => ({
                                ...prev,
                                tanggal_lahir: e.target.value,
                              }))
                            }
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Jenis Kelamin</h4>
                          <select
                            value={newAppointment.jenis_kelamin}
                            onChange={(e) =>
                              setNewAppointment((prev) => ({
                                ...prev,
                                jenis_kelamin: e.target.value,
                              }))
                            }
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          >
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                          </select>
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Alamat</h4>
                        <textarea
                          value={newAppointment.alamat}
                          onChange={(e) =>
                            setNewAppointment((prev) => ({
                              ...prev,
                              alamat: e.target.value,
                            }))
                          }
                          rows={2}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="Masukkan alamat lengkap"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">No. Telepon</h4>
                          <input
                            type="tel"
                            value={newAppointment.no_telepon}
                            onChange={(e) =>
                              setNewAppointment((prev) => ({
                                ...prev,
                                no_telepon: e.target.value,
                              }))
                            }
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            placeholder="Masukkan nomor telepon"
                          />
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Email</h4>
                          <input
                            type="email"
                            value={newAppointment.email}
                            onChange={(e) =>
                              setNewAppointment((prev) => ({
                                ...prev,
                                email: e.target.value,
                              }))
                            }
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            placeholder="Masukkan email"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-4">
                    <h4 className="font-medium text-gray-900">Data Kunjungan</h4>
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Dokter</h4>
                      <select
                        value={newAppointment.doctorId}
                        onChange={(e) => {
                          const doctor = doctors.find(d => d.id === parseInt(e.target.value, 10));
                          setNewAppointment(prev => ({
                            ...prev,
                            doctorId: e.target.value,
                            doctor: doctor ? doctor.name : ''
                          }));
                        }}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      >
                        <option value="">Pilih Dokter</option>
                        {doctors.map(doctor => (
                          <option key={doctor.id} value={doctor.id}>{doctor.name}</option>
                        ))}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Tanggal</h4>
                        <input
                          type="date"
                          value={newAppointment.date}
                          onChange={(e) => setNewAppointment(prev => ({ ...prev, date: e.target.value }))}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Waktu</h4>
                        <select
                          value={newAppointment.time}
                          onChange={(e) => setNewAppointment(prev => ({ ...prev, time: e.target.value }))}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        >
                          {timeSlots.map(slot => (
                            <option key={slot.time} value={slot.time}>{slot.label}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Poliklinik</h4>
                      <select
                        value={newAppointment.poli}
                        onChange={(e) => setNewAppointment(prev => ({ ...prev, poli: e.target.value }))}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      >
                        <option value="umum">Umum</option>
                        <option value="gigi">Gigi</option>
                        <option value="anak">Anak</option>
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Height (cm)</h4>
                        <input
                          type="number"
                          value={newAppointment.height}
                          onChange={(e) => setNewAppointment(prev => ({ ...prev, height: e.target.value }))}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="Masukkan tinggi"
                          required
                        />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Weight (kg)</h4>
                        <input
                          type="number"
                          value={newAppointment.weight}
                          onChange={(e) => setNewAppointment(prev => ({ ...prev, weight: e.target.value }))}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="Masukkan berat"
                          required
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Heart Rate (bpm)</h4>
                        <input
                          type="number"
                          value={newAppointment.heart_rate}
                          onChange={(e) => setNewAppointment(prev => ({ ...prev, heart_rate: e.target.value }))}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="Masukkan detak jantung"
                          required
                        />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Blood Sugar (mg/dL)</h4>
                        <input
                          type="number"
                          value={newAppointment.blood_sugar}
                          onChange={(e) => setNewAppointment(prev => ({ ...prev, blood_sugar: e.target.value }))}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          placeholder="Masukkan gula darah"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Temperature (°C)</h4>
                      <input
                        type="number"
                        step="0.1"
                        value={newAppointment.temperature}
                        onChange={(e) => setNewAppointment(prev => ({ ...prev, temperature: e.target.value }))}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        placeholder="Masukkan suhu"
                        required
                      />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Complaint</h4>
                      <textarea
                        value={newAppointment.complaint}
                        onChange={(e) => setNewAppointment(prev => ({ ...prev, complaint: e.target.value }))}
                        rows={2}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        placeholder="Masukkan keluhan"
                        required
                      />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-500">Catatan</h4>
                      <textarea
                        value={newAppointment.notes}
                        onChange={(e) => setNewAppointment(prev => ({ ...prev, notes: e.target.value }))}
                        rows={3}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        placeholder="Tambahkan catatan jika diperlukan"
                      />
                    </div>
                  </div>
                </div>
              )}

              {modalType === 'detail' && (
                <div className="space-y-6">
                  {!isEditing ? (
                    <>
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Nama Pasien</h4>
                          <p className="mt-1 text-gray-900">{selectedAppointment.patientName}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Dokter</h4>
                          <p className="mt-1 text-gray-900">{selectedAppointment.doctor}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-sm font-medium text-gray-500">Tanggal</h4>
                            <p className="mt-1 text-gray-900">
                              {format(new Date(selectedAppointment.date), 'dd MMM yyyy')}
                            </p>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500">Waktu</h4>
                            <p className="mt-1 text-gray-900">{selectedAppointment.time}</p>
                          </div>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Status</h4>
                          <p className="mt-1 text-gray-900">{selectedAppointment.status}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Poliklinik</h4>
                          <p className="mt-1 text-gray-900">{selectedAppointment.poli}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Catatan</h4>
                          <p className="mt-1 text-gray-900">{selectedAppointment.notes || '-'}</p>
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Nama Pasien</h4>
                          <p className="mt-1 text-gray-900">{editedAppointment.patientName}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Dokter</h4>
                          <select
                            value={editedAppointment.doctorId}
                            onChange={(e) => {
                              const doctor = doctors.find((d) => d.id === parseInt(e.target.value, 10));
                              setEditedAppointment((prev) => ({
                                ...prev,
                                doctorId: e.target.value,
                                doctor: doctor ? doctor.name : '',
                              }));
                            }}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          >
                            {doctors.map((doctor) => (
                              <option key={doctor.id} value={doctor.id}>
                                {doctor.name}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-sm font-medium text-gray-500">Tanggal</h4>
                            <input
                              type="date"
                              value={editedAppointment.date}
                              onChange={(e) =>
                                setEditedAppointment((prev) => ({ ...prev, date: e.target.value }))
                              }
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            />
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-gray-500">Waktu</h4>
                            <select
                              value={editedAppointment.time}
                              onChange={(e) =>
                                setEditedAppointment((prev) => ({ ...prev, time: e.target.value }))
                              }
                              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            >
                              {timeSlots.map((slot) => (
                                <option key={slot.time} value={slot.time}>
                                  {slot.label}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Status</h4>
                          <select
                            value={editedAppointment.status}
                            onChange={(e) =>
                              setEditedAppointment((prev) => ({ ...prev, status: e.target.value }))
                            }
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          >
                            <option value="scheduled">Scheduled</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Poliklinik</h4>
                          <select
                            value={editedAppointment.poli}
                            onChange={(e) =>
                              setEditedAppointment((prev) => ({ ...prev, poli: e.target.value }))
                            }
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          >
                            <option value="umum">Umum</option>
                            <option value="gigi">Gigi</option>
                            <option value="anak">Anak</option>
                          </select>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Catatan</h4>
                          <textarea
                            value={editedAppointment.notes}
                            onChange={(e) =>
                              setEditedAppointment((prev) => ({ ...prev, notes: e.target.value }))
                            }
                            rows={3}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                          />
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>

            <div className="border-t px-6 py-4 bg-gray-50 flex justify-end gap-3">
              {modalType === 'new' ? (
                <>
                  <button
                    onClick={handleCloseModal}
                    className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-800"
                  >
                    Batal
                  </button>
                  <button
                    onClick={() => {
                      setConfirmAction(() => handleCreateAppointment);
                      setShowConfirmModal(true);
                    }}
                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md"
                  >
                    Simpan
                  </button>
                </>
              ) : (
                <>
                  {!isEditing ? (
                    <>
                      <button
                        onClick={handleDeleteClick}
                        className="px-4 py-2 text-sm font-medium text-red-600 hover:text-red-700"
                      >
                        Hapus
                      </button>
                      <button
                        onClick={handleEditClick}
                        className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md"
                      >
                        Edit
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={handleEditCancel}
                        className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-800"
                      >
                        Batal
                      </button>
                      <button
                        onClick={handleEditSubmit}
                        className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md"
                      >
                        Simpan
                      </button>
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {showConfirmModal && (
        <div className="fixed inset-0 bg-[rgba(0,0,0,0.5)] flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-3">
              Konfirmasi
            </h3>
            <p className="text-gray-500 mb-6">
              Apakah Anda yakin ingin menyimpan perubahan ini?
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-800"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  confirmAction();
                  setShowConfirmModal(false);
                }}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md"
              >
                Ya, Simpan
              </button>
            </div>
          </div>
        </div>
      )}
    </PageTemplate>
  );
};

export default RawatJalan;
